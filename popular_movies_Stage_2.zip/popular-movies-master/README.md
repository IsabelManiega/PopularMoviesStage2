# Popular-Movies-Stage-2
Udacity Android Nanodegree project #2


Instructions for user:
  For full functionality, an api key must be provided:<br />
    1. Head over to <project folder>/app/src/main/res/values/api_config.xml<br />
    2. Place your api key in line 3 at the appropriate xml tag

